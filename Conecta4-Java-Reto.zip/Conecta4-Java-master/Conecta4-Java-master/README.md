# Conecta4-Java
Primer Reto Mensual de Mouredev

## Reglas 
- El conecta 4 se juega en una rejilla vertical de 6 filas y 7 columnas.
- El objetivo es alinear 4 fichas de su color, horizontalmente, verticalmente o en diagonal.

## Imagenes en Juego
<img src="/fotos/tablero.png" alt="Tablero">
<img src="/fotos/EnPartida.png" alt="En partida">
<img src="/fotos/Empate.png" alt="Empate">
<img src="/fotos/Victoria.png" alt="Victoria">

# Oscar Alexander Cruz Lopez
